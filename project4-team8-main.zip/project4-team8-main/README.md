# project4-team8

# Faculty Page Redesign - README

## Team Members
- Sam Zhang
- Luke Rako
- Alex Hewitt
- Hamzah Chaudhry

## Project Description
Many CSE faculty members maintain web pages with information about their research, teaching, and service activities. In this project, our team aims to redesign and improve one professor's web page.

### Project Requirements
1. **Professionalism:**
   - The redesigned site should meet professional standards, suitable for demonstration to parents and the respective faculty member.

2. **Fidelity:**
   - While the style and organization can differ, all factual information in the redesigned site must be accurate and taken from the original.
   - The redesigned site should be relatively complete, encompassing most or all of the information in the original.

3. **Size:**
   - The site should consist of at least three pages, organized in a coherent manner with proper cross-linking.

4. **Content:**
   - Include at least one table and one image in the redesigned site.

5. **Technology:**
   - The site must be generated using Middleman.
   - Utilize only core technologies such as HTML, CSS, Markdown, ERb, YAML, etc.
   - Do not use JavaScript or any web design frameworks (e.g., Bootstrap, Foundation).

6. **Validity:**
   - Ensure the completed project is fully validated HTML and CSS.

7. **Compatibility:**
   - Focus on visual appearance in the virtual machine's browser (Firefox or Chrome) without concern for cross-browser or cross-platform compatibility.

## Instructions for Running the Project

#### Note: Middleman must be installed.

1. **Clone the Repository:**
    ```bash
    git clone [repository_url]
    ```

2. **Navigate to Project Directory:**
    ```bash
    cd [project_directory]
    ```

3. **Install Dependencies:**
    ```bash
    bundle install
    ```

4. **Run Middleman Server:**
    ```bash
    bundle exec middleman server
    ```

5. **Access the Site:**
    - Open a web browser and visit [http://localhost:4567](http://localhost:4567) to view the redesigned site.

## Note

For any inquiries or clarifications regarding the project, please contact a group member.
